# Dispersiyon Sayfası Yeniden Tasarım Spesifikasyonu

**Tarih:** 2026-05-02  
**Kapsam:** Mevcut Dispersiyon / Bead Mill ekranının bilimsel ve mühendislik temelli olarak genişletilmesi  
**Yaklaşım:** Mevcut kodu sıfırdan yazmak yerine genişletmek (extend)

---

## 1. Genel Mimari

Tek sayfa, dikey akan **accordion** düzeni. 4 numaralı modül üstten alta sıralanır; her modül açılıp kapanabilir. Sayfanın en üstünde tüm modüllerin paylaştığı **Global Pigment Paneli** bulunur.

### Veri akışı
```
Global Panel → Modül 1 (HSD) → [otomatik] → Modül 2 (Bead Mill)
                                              ↓
                                    Modül 3 (Letdown)
                                    Modül 4 (Maliyet)
```

Modül 1'in çıktısı olan **feed d₅₀ (≈5 µm)** Modül 2'nin girdi alanına otomatik yazılır; kullanıcı override edebilir.

---

## 2. Global Pigment Paneli

Tüm modüllerin üstünde sabit kalan paylaşılan giriş alanları:

| Alan | Tip | Örnek |
|------|-----|-------|
| Pigment tipi | Dropdown | TiO₂, Karbon Siyahı, Organik, Anorganik |
| Hedef d₅₀ (µm) | Number | 0.3 |
| Batch kütlesi (kg) | Number | 100 |
| Pigment konsantrasyonu (wt%) | Number | 35 |
| Baz tipi | Dropdown | Su bazlı, Solvent bazlı |

Pigment tipi seçimi şunları etkiler: Wi (Bond Work Index), dinamik η katsayısı, Letdown risk profili.

---

## 3. Modül 1 — HSD Pre-mixer

**Fizik arka planı:** Aglomerat kırma 40–50 kJ/mol enerji rejimi. Bead mill tek başına verimli değildir; HSD ön işlemi zorunludur.

### Girdi
- Bıçak çapı D (mm)
- Tank çapı T (mm)
- Dönme hızı N (RPM)

### Hesaplama
```
Uç hızı  TS = π · D · N / 60       [m/s]
Oran     r  = D / T
Ön karıştırma süresi  t_pre = f(TS, konsantrasyon)   [dk]
```

### Çıktı & Doğrulama
- **TS:** Hedef 10–20 m/s aralığı; dışındaysa uyarı
- **r:** Hedef 0.30–0.40; 0.33 ideal; dışındaysa uyarı
- **t_pre:** Tahmini ön karıştırma süresi (dakika)
- **HSD sonrası d₅₀ ≈ 5 µm** → Modül 2 feed alanına otomatik aktarılır

---

## 4. Modül 2 — Bead Mill (Geliştirilmiş Motor)

**Fizik arka planı:** Agregat kırma 600–1000 kJ/mol. Bond 3. Yasa + Kwade SI modeli korunur; sabit η=0.4 yerine dinamik η eklenir.

### Girdi
- Feed d₅₀ (µm) — Modül 1'den otomatik, override edilebilir
- Boncuk çapı d_b (mm)
- Boncuk yoğunluğu ρ_b (g/cm³)
- Değirmen uç hızı v_t (m/s)
- Hedef d₅₀ (µm) — Global panelden otomatik

### Hesaplama (mevcut motor korunur, genişletilir)
```
SI  = ρ_b · d_b³ · v_t²                  [Kwade 1999]
Em  = Wi · 10 · (1/√P - 1/√F) / η        [Bond 1952]
η   = f(pigment_tipi, konsantrasyon)       [dinamik, sabit 0.4 yerine]
d₈₀ = d₅₀ × 1.4    (yaklaşık)
d₉₈ = d₅₀ × 2.2    (yaklaşık)
SPAN = (d₉₀ - d₁₀) / d₅₀
```

### Çıktı
- Pas sayısı / öğütme süresi (mevcut)
- d₅₀ azalma grafiği (mevcut)
- **Yeni:** d₅₀ / d₈₀ / d₉₈ + SPAN gösterimi
- **Yeni:** Dinamik η değeri ve açıklaması

---

## 5. Modül 3 — Letdown Risk Analizi

**Fizik arka planı:** Letdown solventinin reçineyle polarite uyumsuzluğu → dispersant pigment yüzeyinden soyulur → floating → renk hatası.

### Girdi
- Reçine tipi (dropdown: Akrilik, Alkid, Epoksi, PU, Nitroselüloz)
- Letdown solvent (dropdown: Su, Mineral spirit, Toluen, Aseton, Etanol, ...)
- Pasta sıcaklığı T₁ (°C)
- Letdown sıcaklığı T₂ (°C)

### Hesaplama
Risk skoru = f(polarite_farkı, ΔT, baz_uyumu)

### Çıktı
- Risk seviyesi: **Yeşil** (güvenli) / **Sarı** (dikkat) / **Kırmızı** (risk)
- Açıklama metni: hangi mekanizma devreye girebilir
- Öneri: solvent değişimi veya ekleme sırası

---

## 6. Modül 4 — Maliyet & Enerji Analizi

Tüm modüllerin süre ve enerji verilerini toplayarak ekonomik özet üretir.

### Girdi
- **Elektrik birim fiyatı (₺/kWh)** — kullanıcı girer, varsayılan güncel değer (zamlara karşı güncellenebilir)
- HSD motor gücü (kW) — opsiyonel, yoksa tahmin
- Bead mill motor gücü (kW) — opsiyonel, yoksa tahmin

### Hesaplama
```
E_toplam = E_hsd + E_beadmill           [kWh/ton]
Maliyet  = E_toplam × birim_fiyat       [₺/ton]
CO₂      = E_toplam × 0.415            [kg CO₂/ton, Türkiye grid faktörü]
```

### Çıktı
| Metrik | Birim |
|--------|-------|
| Toplam enerji | kWh/ton |
| Enerji maliyeti | ₺/ton |
| CO₂ tahmini | kg/ton |
| Toplam proses süresi | dakika |

---

## 7. Kapsam Dışı (Bu İterasyonda)

Aşağıdaki modüller tasarlandı ancak bu iterasyona dahil edilmedi:

- **Dispersant Seçici** — pigment tipine göre anchor grubu + mekanizma önerisi
- **Kalite Kontrol Paneli** — Hegman↔µm çevirici, geçiş protokol tablosu

---

## 8. Teknik Notlar

- Mevcut `pageDispersion` bölümü (index.html ~744–1031. satırlar) genişletilir, yeniden yazılmaz
- Global panel verisi JavaScript state'inde tutulur; modüller reaktif olarak okur
- HSD→Bead Mill veri aktarımı: Modül 1 hesaplandığında feed d₅₀ alanı otomatik doldurulur ama kullanıcı edit edebilir
- Accordion state localStorage'a kaydedilebilir (opsiyonel)
- Mevcut d₅₀ grafiği ve SI grafiği Modül 2 içinde kalır

---

## 9. Başarı Kriterleri

1. HSD uç hızı hesaplanır ve optimal aralık kontrolü yapılır
2. Feed d₅₀ Modül 1'den Modül 2'ye otomatik akar
3. Bead mill hesabı dinamik η kullanır (pigment tipine göre)
4. Letdown risk skoru renk kodlu gösterilir
5. Elektrik fiyatı değiştirince tüm maliyet hesabı güncellenir
