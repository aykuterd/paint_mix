# Torispherical Alt Bombe — CFD Tab Entegrasyonu

**Tarih:** 2026-05-06
**Durum:** Onaylandı
**Kapsam:** CFD sekmesi — silindirik tank alt bombesi (Klöpperboden, DIN 28011)

---

## 1. Amaç

Boya sanayii karıştırma tanklarının altı düz değil, torispherical (Klöpperboden) şeklindedir. Bu özellik:
- Sıvı dolum hacmini etkiler (bombe ekstra hacim katar)
- Tank doluluk % hesabını etkiler
- Görselleştirmede curved bottom gösterilmelidir

Şu anki kod düz alt varsayıyor. Bu spec, bombe hacminin hesaba katılmasını, çizime eklenmesini ve UI'da gösterilmesini tanımlar.

---

## 2. Kapsam Dışı

- `cfd-engine.js` fizik modeli değişmez (stream function, ADE solver dokunulmaz)
- Bombe bölgesinde CFD hücre simülasyonu yok (Yaklaşım A seçildi)
- Diğer sekmeler (Karıştırma, Dispersion, Uygunluk) değişmez

---

## 3. Teknik Altyapı — Torispherical (DIN 28011)

**Kaynak:** Perry's Chemical Engineers' Handbook, 8th Ed.; DIN 28011 Klöpperboden standardı

### Parametreler
- Crown radius: `R_c = D = T` (tank çapına eşit)
- Knuckle radius: `r_k = 0.1 · T`
- Bombe derinliği: `h_bombe = T · (1 − √0.65) ≈ 0.1938 · T`
- Tam bombe hacmi: `V_bombe = 0.0847 · T³`

### Türetme (Perry's doğrulaması)
```
h_bombe = R_c − √((R_c − r_k)² − (T/2 − r_k)²)
         = T − √((0.9T)² − (0.4T)²)
         = T − √(0.65) · T
         = T · (1 − 0.8062)
         ≈ 0.1938 · T
```

Hacim katsayısı `0.0847` Perry's Table 10-59 bölgesinden alınmıştır (standard torispherical head).

---

## 4. Hacim Hesabı Değişiklikleri

**Dosya:** `cfd-ui.js` → `cfdGetParams()` ve `cfdUpdateLiqInfo()`

### Mevcut
```js
const V_liq = kg / rho;
const H_liq = V_liq / (Math.PI / 4 * T * T);
```

### Yeni
```js
// Torispherical bombe (DIN 28011)
const V_bombe = 0.0847 * T * T * T;
const h_bombe = T * (1 - Math.sqrt(0.65));

const V_liq = kg / rho;
// Sıvı bombe + silindir doldurur; H_liq silindir kısmının yüksekliği
const V_cyl = Math.max(0, V_liq - V_bombe);
let H_liq = V_cyl / (Math.PI / 4 * T * T);
H_liq = Math.max(0, Math.min(H_liq, Htank));
```

### Edge Cases
- `V_liq ≤ V_bombe`: Sıvı tamamı bombe içinde → `H_liq = 0`
- `V_liq > V_tank_total + V_bombe`: `H_liq` Htank'ta kırpılır (taşma yok)

### `cfdGetParams()` dönüş değerine eklenenler
```js
V_bombe,   // m³
h_bombe,   // m
Vtotal,    // m³ — π/4·T²·Htank + V_bombe (toplam tank kapasitesi)
```

### `cfdUpdateLiqInfo(p)` güncellemesi
- `cfd_bombeVol` span: `(V_bombe * 1000).toFixed(0) + ' L'`
- `cfd_bombeH` span: `h_bombe.toFixed(3) + ' m'`
- Doluluk %: `(V_liq / Vtotal * 100).toFixed(0) + '%'`

---

## 5. Canvas Çizim Değişiklikleri

**Dosya:** `cfd-render.js` → `cfdDrawSideView()`

### Mevcut
```js
ctx.strokeRect(pad.left, pad.top, dW, dH);
```

### Yeni Mantık
```
1. botY = pad.top + dH   (silindir alt kenarı — mevcut gibi)
2. bombePx = Math.round(dH * h_bombe / Htank)  (orantılı, Htank'a göre ölçeklenir)
3. Tank kontur çizgisi:
   - Sol duvar: (pad.left, pad.top) → (pad.left, botY)
   - Sağ duvar: (pad.left+dW, pad.top) → (pad.left+dW, botY)
   - Curved bottom: bezierCurveTo ile torispherical profil
   - Üst: strokeLine pad.top boyunca (açık — kapak yok)
4. Curved bottom bezier (sol yarı, eksen simetrik):
   ctx.beginPath()
   ctx.moveTo(pad.left, botY)
   ctx.bezierCurveTo(
     pad.left, botY + bombePx * 0.6,         // ctrl1
     cx - dW*0.1, botY + bombePx,            // ctrl2
     cx, botY + bombePx                       // bitiş: eksen
   )
   — sağ yarı: ayna simetrik
5. Sıvı dolgu: bombe içini de kapsar (path: liqTopY → botY → curved bottom → botY → liqTopY)
```

### Ayna Görünümü Uyumluluğu
Mevcut kod sol+sağ simetrik çiziyor (eksen ortada). Bombe eğrisi de simetrik — her iki yarı için aynı bezier uygulanır. CFD hücreleri `liqTopY → botY` aralığında kalır; bombe `botY` altına grafik olarak eklenir.

---

## 6. HTML Değişiklikleri

**Dosya:** `cfd-page.html`

Mevcut dolum bilgi grid'ine 2 satır eklenir:

```html
<!-- Bombe Hacmi -->
<span class="label">Bombe (Torispherical)</span>
<span id="cfd_bombeVol">—</span>

<!-- Bombe Derinliği -->
<span class="label">Bombe Derinliği</span>
<span id="cfd_bombeH">—</span>
```

---

## 7. Tank Seçici Entegrasyonu

**Dosya:** `cfd-ui.js` → `cfdSelectTank()`

```js
// Mevcut:
const kg_def = Math.round((tank.kullanilabilir_lt || 1500) * rho_def / 1000);

// Yeni:
const T_tank = tank.ic_cap_m || 1.3;
const V_bombe_tank = 0.0847 * T_tank * T_tank * T_tank;
const V_cyl_lt = (tank.kullanilabilir_lt || 1500) / 1000; // m³
const kg_def = Math.round((V_cyl_lt + V_bombe_tank) * rho_def);
```

Tank seçildiğinde kg alanı, silindir + bombe hacmine karşılık gelen kütleyi gösterir.

---

## 8. Etkilenen Dosyalar

| Dosya | Değişiklik |
|-------|-----------|
| `cfd-ui.js` | `cfdGetParams()`, `cfdUpdateLiqInfo()`, `cfdSelectTank()` |
| `cfd-render.js` | `cfdDrawSideView()` — curved bottom |
| `cfd-page.html` | 2 yeni span eklenir |
| `cfd-engine.js` | **Değişmez** |

---

## 9. Test Kriterleri

- T=1.3 m → V_bombe ≈ 0.186 m³ (186 L), h_bombe ≈ 0.252 m
- T=1.0 m → V_bombe ≈ 0.0847 m³ (84.7 L), h_bombe ≈ 0.194 m
- kg=0: H_liq=0, doluluk=0%
- kg çok az (sıvı sadece bombeyi dolduruyor): H_liq=0, doluluk < V_bombe/Vtotal
- Tank seçiciden yüklenince kg doğru hesaplanır
- Canvas'ta curved bottom görünür
