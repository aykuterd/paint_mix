# Dispersiyon Sayfası Yeniden Tasarım Implementasyon Planı

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Mevcut Dispersiyon sayfasını HSD Pre-mixer, geliştirilmiş Bead Mill, Letdown Risk ve Maliyet modülleri içeren dikey accordion düzenine genişletmek.

**Architecture:** Tek HTML dosyası (`index.html`). Mevcut `#pageDispersion` bölümü yerinde tutulur; içeriği 4 accordion modüle dönüştürülür. Global Pigment Paneli tüm modüllerin üstünde paylaşılan giriş alanlarını tutar. HSD→Bead Mill veri akışı JavaScript state ile sağlanır.

**Tech Stack:** Vanilla JS, Tailwind CSS (CDN), Chart.js (canvas), HTML5 — mevcut stack değişmez.

---

## Dosya Yapısı

- Modify: `index.html` satır 744–1031 (`#pageDispersion` bloğu) — tüm HTML ve JS değişiklikleri burada
- Mevcut `DP_PIGMENTS`, `DP_BEADS`, `DP_MILL_ETA`, `dpCompute`, `dpDrawChart`, `dpDrawSIChart` fonksiyonları korunur ve genişletilir

---

## Task 1: Global Pigment Paneli + Accordion İskeleti

**Files:**
- Modify: `index.html` satır 745–1031

- [ ] **Adım 1: Mevcut `#pageDispersion` içeriğini yedekle**

`index.html`'de satır 744–1031 arası içeriği `<!-- YEDEK BAŞLANGICI -->` / `<!-- YEDEK SONU -->` yorumlarıyla işaretle. Silinmeyecek — geriye referans olarak kalacak.

- [ ] **Adım 2: `#pageDispersion` içeriğini accordion iskeletiyle değiştir**

Satır 746'dan itibaren (`<div class="max-w-[1600px] mx-auto">` içini) şu yapıyla değiştir:

```html
<div class="max-w-[1400px] mx-auto space-y-4 pb-12">

  <!-- GLOBAL PİGMENT PANELİ -->
  <div class="glass-card p-5" id="dp_globalPanel">
    <div class="flex items-center gap-2 mb-4" style="color:#a78bfa">
      <i class="fas fa-circle-nodes text-sm"></i>
      <h2 class="font-black uppercase text-xs tracking-widest">Pigment & Hedef — Tüm Modüller Paylaşır</h2>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Pigment Tipi</label>
        <select id="dp_pigType" class="input-dark" onchange="dpOnGlobalChange()">
          <option value="tio2">TiO₂ (Rutil) — Wi=15</option>
          <option value="fe2o3">Fe₂O₃ (Demir Oksit) — Wi=12</option>
          <option value="caco3">CaCO₃ (Kalsit) — Wi=8</option>
          <option value="organic">Organik Pigment — Wi=5</option>
          <option value="cb">Karbon Siyahı — Wi=3</option>
          <option value="baso4">BaSO₄ — Wi=10</option>
        </select>
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Hedef d₅₀ (µm)</label>
        <input type="number" id="dp_d50target" value="0.3" step="0.05" min="0.01" class="input-dark" oninput="dpOnGlobalChange()">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Batch (kg)</label>
        <input type="number" id="dp_batchKg" value="100" step="5" min="1" class="input-dark" oninput="dpOnGlobalChange()">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Konsantrasyon (wt%)</label>
        <input type="number" id="dp_solidPct" value="35" step="5" min="5" max="70" class="input-dark" oninput="dpOnGlobalChange()">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Baz</label>
        <select id="dp_baseType" class="input-dark">
          <option value="water">Su bazlı</option>
          <option value="solvent">Solvent bazlı</option>
        </select>
      </div>
    </div>
  </div>

  <!-- MODÜL 1: HSD -->
  <div class="rounded-xl overflow-hidden" style="border:1px solid rgba(124,58,237,0.35)" id="dp_mod1">
    <div class="flex items-center justify-between px-5 py-3 cursor-pointer select-none"
         style="background:rgba(124,58,237,0.12)"
         onclick="dpToggle('dp_mod1_body','dp_mod1_arrow')">
      <div class="flex items-center gap-3">
        <span class="flex items-center justify-center w-6 h-6 rounded-full text-white text-xs font-black"
              style="background:#7c3aed">1</span>
        <span class="font-black text-sm" style="color:#c4b5fd">HSD Pre-mixer — Islatma & Aglomerat Kırma</span>
        <span class="text-[9px] text-slate-500">~40–50 kJ/mol enerji rejimi</span>
      </div>
      <div class="flex items-center gap-3">
        <span id="dp_mod1_badge" class="text-[9px] px-2 py-0.5 rounded"
              style="background:rgba(100,116,139,0.2);color:#64748b">—</span>
        <i id="dp_mod1_arrow" class="fas fa-chevron-down text-slate-500 transition-transform"></i>
      </div>
    </div>
    <div id="dp_mod1_body" class="p-5" style="background:#0a0f1e">
      <!-- HSD içeriği Task 2'de eklenir -->
    </div>
  </div>

  <!-- MODÜL 2: BEAD MILL -->
  <div class="rounded-xl overflow-hidden" style="border:1px solid rgba(234,88,12,0.35)" id="dp_mod2">
    <div class="flex items-center justify-between px-5 py-3 cursor-pointer select-none"
         style="background:rgba(234,88,12,0.12)"
         onclick="dpToggle('dp_mod2_body','dp_mod2_arrow')">
      <div class="flex items-center gap-3">
        <span class="flex items-center justify-center w-6 h-6 rounded-full text-white text-xs font-black"
              style="background:#ea580c">2</span>
        <span class="font-black text-sm" style="color:#fdba74">Bead Mill — Pigment Öğütme</span>
        <span class="text-[9px] text-slate-500">Bond (1952) + Kwade (1999) + Dinamik η</span>
      </div>
      <div class="flex items-center gap-3">
        <span id="dp_mod2_badge" class="text-[9px] px-2 py-0.5 rounded"
              style="background:rgba(100,116,139,0.2);color:#64748b">—</span>
        <i id="dp_mod2_arrow" class="fas fa-chevron-down text-slate-500 transition-transform"></i>
      </div>
    </div>
    <div id="dp_mod2_body" class="p-5" style="background:#0a0f1e">
      <!-- Bead Mill içeriği Task 3'te eklenir -->
    </div>
  </div>

  <!-- MODÜL 3: LETDOWN RİSK -->
  <div class="rounded-xl overflow-hidden" style="border:1px solid rgba(20,184,166,0.35)" id="dp_mod3">
    <div class="flex items-center justify-between px-5 py-3 cursor-pointer select-none"
         style="background:rgba(20,184,166,0.12)"
         onclick="dpToggle('dp_mod3_body','dp_mod3_arrow')">
      <div class="flex items-center gap-3">
        <span class="flex items-center justify-center w-6 h-6 rounded-full text-white text-xs font-black"
              style="background:#14b8a6">3</span>
        <span class="font-black text-sm" style="color:#5eead4">Letdown Risk Analizi</span>
        <span class="text-[9px] text-slate-500">Solvent uyumu, floating riski, re-flokülasyon</span>
      </div>
      <div class="flex items-center gap-3">
        <span id="dp_mod3_badge" class="text-[9px] px-2 py-0.5 rounded"
              style="background:rgba(100,116,139,0.2);color:#64748b">—</span>
        <i id="dp_mod3_arrow" class="fas fa-chevron-down text-slate-500 transition-transform"></i>
      </div>
    </div>
    <div id="dp_mod3_body" class="p-5" style="background:#0a0f1e">
      <!-- Letdown içeriği Task 4'te eklenir -->
    </div>
  </div>

  <!-- MODÜL 4: MALİYET & ENERJİ -->
  <div class="rounded-xl overflow-hidden" style="border:1px solid rgba(34,197,94,0.35)" id="dp_mod4">
    <div class="flex items-center justify-between px-5 py-3 cursor-pointer select-none"
         style="background:rgba(34,197,94,0.12)"
         onclick="dpToggle('dp_mod4_body','dp_mod4_arrow')">
      <div class="flex items-center gap-3">
        <span class="flex items-center justify-center w-6 h-6 rounded-full text-white text-xs font-black"
              style="background:#22c55e">4</span>
        <span class="font-black text-sm" style="color:#86efac">Maliyet & Enerji Analizi</span>
        <span class="text-[9px] text-slate-500">kWh/ton, ₺/ton, CO₂ kg/ton</span>
      </div>
      <div class="flex items-center gap-3">
        <span id="dp_mod4_badge" class="text-[9px] px-2 py-0.5 rounded"
              style="background:rgba(100,116,139,0.2);color:#64748b">—</span>
        <i id="dp_mod4_arrow" class="fas fa-chevron-down text-slate-500 transition-transform"></i>
      </div>
    </div>
    <div id="dp_mod4_body" class="p-5" style="background:#0a0f1e">
      <!-- Maliyet içeriği Task 5'te eklenir -->
    </div>
  </div>

</div>
```

- [ ] **Adım 3: Accordion toggle JS fonksiyonunu ekle**

Mevcut `dpGetParams` fonksiyonundan önce (satır ~3338) şunu ekle:

```javascript
function dpToggle(bodyId, arrowId) {
    const body = document.getElementById(bodyId);
    const arrow = document.getElementById(arrowId);
    const isHidden = body.style.display === 'none';
    body.style.display = isHidden ? '' : 'none';
    arrow.style.transform = isHidden ? 'rotate(180deg)' : '';
}

function dpOnGlobalChange() {
    // Global panel değişince Modül 1 badge'ini sıfırla
    document.getElementById('dp_mod1_badge').textContent = '—';
    document.getElementById('dp_mod1_badge').style.color = '#64748b';
    document.getElementById('dp_mod2_badge').textContent = '—';
    document.getElementById('dp_mod2_badge').style.color = '#64748b';
}
```

- [ ] **Adım 4: Sayfayı aç, accordion başlıklarının görüntülendiğini kontrol et**

`open index.html` → Dispersiyon sekmesine geç → 4 modül başlığının göründüğünü, tıklandığında açılıp kapandığını doğrula.

- [ ] **Adım 5: Commit**

```bash
git add index.html
git commit -m "feat: dispersion page accordion skeleton with global pigment panel"
```

---

## Task 2: Modül 1 — HSD Pre-mixer HTML + JS

**Files:**
- Modify: `index.html` — `dp_mod1_body` içi + JS bölümü

- [ ] **Adım 1: `dp_mod1_body` içine HSD giriş + sonuç HTML ekle**

`<!-- HSD içeriği Task 2'de eklenir -->` satırını sil ve şununla değiştir:

```html
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Parametreler -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-3 tracking-widest">Parametreler</div>
    <div class="space-y-3">
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Bıçak Çapı D (mm)</label>
        <input type="number" id="hsd_bladeD" value="250" step="10" min="50" class="input-dark">
        <p class="text-[9px] text-slate-500 mt-1">Tipik: 200–400 mm arası</p>
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Tank Çapı T (mm)</label>
        <input type="number" id="hsd_tankD" value="750" step="25" min="100" class="input-dark">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Dönme Hızı N (RPM)</label>
        <input type="number" id="hsd_rpm" value="1450" step="50" min="100" max="5000" class="input-dark">
      </div>
      <button onclick="hsdCalc()" class="w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-widest text-white flex items-center justify-center gap-2 transition"
              style="background:linear-gradient(135deg,#7c3aed,#a855f7)">
        <i class="fas fa-calculator"></i> HSD Hesapla
      </button>
    </div>
  </div>

  <!-- Sonuçlar -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-3 tracking-widest">Sonuçlar</div>
    <div class="space-y-3">
      <div class="rounded-xl p-4 text-center" style="background:#0d1628;border:1px solid rgba(124,58,237,0.2)">
        <p class="text-[9px] text-slate-500 uppercase mb-1">Uç Hızı (TS)</p>
        <p id="hsd_ts" class="text-2xl font-black mono" style="color:#a78bfa">—</p>
        <p id="hsd_ts_status" class="text-[10px] mt-1 font-bold">—</p>
        <p class="text-[8px] text-slate-600 mt-1">TS = π·D·N/60</p>
      </div>
      <div class="rounded-xl p-3 text-center" style="background:#0d1628;border:1px solid rgba(34,197,94,0.15)">
        <p class="text-[9px] text-slate-500 uppercase mb-1">Blade/Tank Oranı</p>
        <p id="hsd_ratio" class="text-xl font-black mono text-green-400">—</p>
        <p id="hsd_ratio_status" class="text-[9px] mt-0.5">—</p>
      </div>
      <div class="rounded-xl p-3 text-center" style="background:#0d1628;border:1px solid rgba(255,255,255,0.05)">
        <p class="text-[9px] text-slate-500 uppercase mb-1">Ön Karıştırma Süresi</p>
        <p id="hsd_time" class="text-xl font-black mono text-yellow-400">—</p>
        <p class="text-[8px] text-slate-600 mt-0.5">t_pre = 900/(TS-5) × konsantrasyon faktörü</p>
      </div>
    </div>
  </div>

  <!-- Çıktı → Aşama 2 -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-3 tracking-widest">Çıktı → Modül 2'ye</div>
    <div class="rounded-xl p-4" style="background:rgba(124,58,237,0.07);border:1px solid rgba(124,58,237,0.2)">
      <p class="text-[9px] text-slate-400 mb-2">HSD sonrası tahmini d₅₀:</p>
      <p id="hsd_out_d50" class="text-2xl font-black mono" style="color:#c4b5fd">—</p>
      <p class="text-[9px] text-slate-600 mt-1">Bead Mill feed d₅₀ olarak aktarılır →</p>
      <button onclick="hsdPushToMod2()" id="hsd_pushBtn"
              class="mt-3 w-full py-2 rounded-lg text-xs font-black uppercase tracking-wider text-white transition"
              style="background:rgba(124,58,237,0.4);border:1px solid rgba(124,58,237,0.5)" disabled>
        Modül 2'ye Aktar →
      </button>
    </div>
    <div class="mt-4 p-3 rounded-xl text-[9px] text-slate-400 leading-relaxed"
         style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.04)">
      <strong class="text-slate-300">Fizik notu:</strong> HSD aglomerat kırma rejimi 40–50 kJ/mol.
      Agregat kırma 600–1000 kJ/mol → bead mill zorunlu.
      <br><em class="text-slate-500">Kaynak: Evonik Dispersant Chemistry Wiki</em>
    </div>
  </div>

</div>
```

- [ ] **Adım 2: HSD JS fonksiyonlarını ekle**

`dpToggle` fonksiyonunun altına ekle:

```javascript
function hsdCalc() {
    const D_mm  = parseFloat(document.getElementById('hsd_bladeD').value);
    const T_mm  = parseFloat(document.getElementById('hsd_tankD').value);
    const N_rpm = parseFloat(document.getElementById('hsd_rpm').value);
    const solidPct = parseFloat(document.getElementById('dp_solidPct').value) / 100;

    // Uç hızı: TS = π·D(m)·N(rps)
    const TS = Math.PI * (D_mm / 1000) * (N_rpm / 60);

    // Blade/Tank oranı
    const ratio = D_mm / T_mm;

    // Ön karıştırma süresi tahmini
    // Yüksek hız → kısa süre; yüksek konsantrasyon → uzun süre
    // Temel formül: t_pre = 600/(TS) × (1 + 2×solidPct) [dk]
    const concFactor = 1 + 2 * solidPct;
    const t_pre = TS > 0 ? Math.max(5, (600 / TS) * concFactor) : 0;

    // HSD sonrası d50 tahmini: aglomerat kırılınca ~3-8 µm aralığı
    // TS yüksekse daha iyi dağılım → daha düşük d50
    const d50_after = TS >= 10 ? 4.0 : TS >= 7 ? 6.0 : 10.0;

    // Durum
    let tsColor, tsStatus;
    if      (TS < 5)             { tsColor='#ef4444'; tsStatus='Çok düşük — islatma gerçekleşmez'; }
    else if (TS < 10)            { tsColor='#f59e0b'; tsStatus='Düşük — yeterli ama optimum altı'; }
    else if (TS <= 20)           { tsColor='#22c55e'; tsStatus='OPTİMUM — 10–20 m/s ideal aralık'; }
    else                         { tsColor='#f59e0b'; tsStatus='Yüksek — hava karışması riski'; }

    let ratioColor, ratioStatus;
    if      (ratio < 0.25)       { ratioColor='#ef4444'; ratioStatus='Çok küçük — donut flow yok'; }
    else if (ratio < 0.30)       { ratioColor='#f59e0b'; ratioStatus='Düşük — akış zayıf'; }
    else if (ratio <= 0.40)      { ratioColor='#22c55e'; ratioStatus='İdeal (0.30–0.40)'; }
    else if (ratio <= 0.50)      { ratioColor='#f59e0b'; ratioStatus='Yüksek — duvar çarpması riski'; }
    else                         { ratioColor='#ef4444'; ratioStatus='Çok büyük — kullanılamaz'; }

    // DOM güncelle
    const tsEl = document.getElementById('hsd_ts');
    tsEl.textContent = TS.toFixed(1) + ' m/s';
    tsEl.style.color = tsColor;
    document.getElementById('hsd_ts_status').textContent = tsStatus;
    document.getElementById('hsd_ts_status').style.color = tsColor;

    const ratioEl = document.getElementById('hsd_ratio');
    ratioEl.textContent = ratio.toFixed(2);
    ratioEl.style.color = ratioColor;
    document.getElementById('hsd_ratio_status').textContent = ratioStatus;
    document.getElementById('hsd_ratio_status').style.color = ratioColor;

    document.getElementById('hsd_time').textContent = t_pre.toFixed(0) + ' dk';

    const outEl = document.getElementById('hsd_out_d50');
    outEl.textContent = '≈ ' + d50_after.toFixed(1) + ' µm';

    const pushBtn = document.getElementById('hsd_pushBtn');
    pushBtn.disabled = false;
    pushBtn.style.background = '#7c3aed';

    // Badge güncelle
    const badge = document.getElementById('dp_mod1_badge');
    badge.textContent = '✓ ' + t_pre.toFixed(0) + ' dk';
    badge.style.cssText = 'background:rgba(74,222,128,0.15);color:#4ade80;border:1px solid rgba(74,222,128,0.3);padding:2px 8px;border-radius:4px;font-size:9px';

    // State'e kaydet
    window._hsdResult = { TS, ratio, t_pre, d50_after };
}

function hsdPushToMod2() {
    if (!window._hsdResult) return;
    const feedEl = document.getElementById('dp_d50feed');
    if (feedEl) {
        feedEl.value = window._hsdResult.d50_after.toFixed(1);
        // Mod2'yi aç
        const body = document.getElementById('dp_mod2_body');
        const arrow = document.getElementById('dp_mod2_arrow');
        if (body && body.style.display === 'none') {
            body.style.display = '';
            if (arrow) arrow.style.transform = 'rotate(180deg)';
        }
        // Görsel bildirim
        feedEl.style.border = '1px solid #7c3aed';
        setTimeout(() => { feedEl.style.border = ''; }, 2000);
    }
}
```

- [ ] **Adım 3: Sayfada test et**

Dispersiyon → Modül 1 aç → bıçak çapı=250, tank=750, RPM=1450 gir → "HSD Hesapla" tıkla.  
Beklenen: TS ≈ 19.0 m/s (yeşil, "OPTİMUM"), oran=0.33 (yeşil), badge "✓ XX dk" gösterir.  
"Modül 2'ye Aktar" tıklayınca Modül 2 açılır, feed d₅₀ güncellenir.

- [ ] **Adım 4: Commit**

```bash
git add index.html
git commit -m "feat: HSD pre-mixer module with tip speed, blade/tank ratio, pre-mix time"
```

---

## Task 3: Modül 2 — Bead Mill HTML + Dinamik η + d80/d98/SPAN

**Files:**
- Modify: `index.html` — `dp_mod2_body` içi + `dpCompute` fonksiyonu

- [ ] **Adım 1: `dp_mod2_body` içine Bead Mill HTML ekle**

`<!-- Bead Mill içeriği Task 3'te eklenir -->` satırını sil ve şununla değiştir:

```html
<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">

  <!-- Sol: Parametreler -->
  <div class="lg:col-span-3 space-y-3">
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Değirmen Parametreleri</div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Besleme d₅₀ (µm)</label>
      <input type="number" id="dp_d50feed" value="5" step="0.5" min="0.1" class="input-dark">
      <p class="text-[9px] text-slate-500 mt-1">HSD çıktısından otomatik doldurulur</p>
    </div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Değirmen Tipi</label>
      <select id="dp_millType" class="input-dark">
        <option value="horizontal">Yatay Diskli — yüksek verim</option>
        <option value="vertical">Dikey — orta verim</option>
        <option value="pin">Pin Mill — yüksek enerji</option>
        <option value="annular">Anüler — dar RTD</option>
      </select>
    </div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Boncuk Materyali</label>
      <select id="dp_beadMat" class="input-dark">
        <option value="zro2">ZrO₂/YTZ (ρ=6050) — önerilen</option>
        <option value="glass">Cam (ρ=2500) — ekonomik</option>
        <option value="alumina">Al₂O₃ (ρ=3900)</option>
        <option value="steel">Çelik (ρ=7800)</option>
        <option value="ce_zro2">Ce-ZrO₂ (ρ=6000)</option>
      </select>
    </div>

    <div class="grid grid-cols-2 gap-2">
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Boncuk Çapı (mm)</label>
        <input type="number" id="dp_beadSize" value="0.8" step="0.1" min="0.1" max="5" class="input-dark">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Boncuk Dolum (%)</label>
        <input type="number" id="dp_beadFill" value="70" step="5" min="50" max="85" class="input-dark">
      </div>
    </div>

    <div>
      <div class="flex justify-between mb-1">
        <label class="text-[9px] font-black text-slate-500 uppercase">Rotor Uç Hızı (m/s)</label>
        <span id="dp_tipLabel" class="text-xs font-black mono" style="color:#a78bfa">9.2 m/s</span>
      </div>
      <input type="range" id="dp_tipSpeed" min="3" max="25" step="0.2" value="9.2" class="w-full"
             style="accent-color:#a855f7"
             oninput="document.getElementById('dp_tipLabel').textContent=parseFloat(this.value).toFixed(1)+' m/s'">
    </div>

    <div class="grid grid-cols-2 gap-2">
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Değirmen Hacmi (L)</label>
        <input type="number" id="dp_millVol" value="1.0" step="0.5" min="0.1" class="input-dark">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Motor Gücü (kW)</label>
        <input type="number" id="dp_motorKw" value="3.0" step="0.5" min="0.1" class="input-dark">
      </div>
    </div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Akış Hızı (L/dk)</label>
      <input type="number" id="dp_flowRate" value="5.0" step="0.5" min="0.1" class="input-dark">
    </div>

    <button id="dp_calcBtn" class="w-full py-3 rounded-xl font-black text-sm uppercase tracking-widest text-white flex items-center justify-center gap-2 shadow-xl transition"
            style="background:linear-gradient(135deg,#ea580c,#f97316)">
      <i class="fas fa-calculator"></i> Bead Mill Hesapla
    </button>
  </div>

  <!-- Orta: Ana Sonuçlar + Grafikler -->
  <div class="lg:col-span-5 space-y-4">

    <!-- Sonuç kartları -->
    <div class="glass-card p-4">
      <div class="flex items-center justify-between mb-3">
        <span class="text-[9px] font-black text-slate-500 uppercase tracking-widest">Hesap Sonuçları</span>
        <button id="dp_resetBtn" class="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition">
          <i class="fas fa-rotate-right text-[9px]"></i>
        </button>
      </div>

      <div class="rounded-xl p-3 border text-center mb-3" style="background:#0a0f1e;border-color:rgba(168,85,247,0.2)">
        <p class="text-[9px] font-black text-slate-500 uppercase mb-1">Stres Yoğunluğu SI</p>
        <p id="dp_siVal" class="text-2xl font-black mono" style="color:#a855f7">—</p>
        <p id="dp_siStatus" class="text-[10px] mt-1 italic font-bold text-slate-400">—</p>
      </div>

      <div class="grid grid-cols-2 gap-2 mb-3">
        <div class="rounded-xl p-3 border" style="background:#0d1628;border-color:rgba(255,255,255,0.05)">
          <p class="text-[9px] text-orange-400 uppercase font-black">Spesifik Enerji</p>
          <p id="dp_emVal" class="text-lg font-black mono text-orange-400 mt-0.5">— kWh/t</p>
          <p id="dp_etaDyn" class="text-[9px] text-slate-500 mt-1">η = —</p>
        </div>
        <div class="rounded-xl p-3 border" style="background:#0d1628;border-color:rgba(255,255,255,0.05)">
          <p class="text-[9px] text-yellow-400 uppercase font-black">Motor Kontrolü</p>
          <p id="dp_powerCheck" class="text-sm font-black mono text-yellow-400 mt-0.5">—</p>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-2 mb-3">
        <div class="rounded-xl p-3 border" style="background:#0d1628;border-color:rgba(34,197,94,0.2)">
          <p class="text-[9px] text-green-400 uppercase font-black">Öğütme Süresi</p>
          <p id="dp_timeVal" class="text-2xl font-black mono text-green-400 mt-1">—</p>
        </div>
        <div class="rounded-xl p-3 border" style="background:#0d1628;border-color:rgba(249,115,22,0.2)">
          <p class="text-[9px] text-orange-400 uppercase font-black">Pas Sayısı</p>
          <p id="dp_passVal" class="text-2xl font-black mono text-orange-400 mt-1">—</p>
        </div>
      </div>

      <!-- d80/d98/SPAN — YENİ -->
      <div class="rounded-xl p-3" style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.04)">
        <p class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Boyut Dağılımı (Hedef d₅₀'de)</p>
        <div class="grid grid-cols-4 gap-2">
          <div class="text-center">
            <p class="text-[8px] text-slate-600 mono">d₅₀</p>
            <p id="dp_d50out" class="text-sm font-black mono text-purple-400">—</p>
          </div>
          <div class="text-center">
            <p class="text-[8px] text-slate-600 mono">d₈₀</p>
            <p id="dp_d80out" class="text-sm font-black mono text-blue-400">—</p>
          </div>
          <div class="text-center">
            <p class="text-[8px] text-slate-600 mono">d₉₈</p>
            <p id="dp_d98out" class="text-sm font-black mono text-red-400">—</p>
          </div>
          <div class="text-center">
            <p class="text-[8px] text-slate-600 mono">SPAN</p>
            <p id="dp_span" class="text-sm font-black mono text-yellow-400">—</p>
          </div>
        </div>
        <p class="text-[8px] text-slate-600 mt-2">SPAN = (d₉₀−d₁₀)/d₅₀. Dar dağılım: SPAN &lt; 1.5</p>
      </div>

      <div class="grid grid-cols-3 gap-2 mt-2">
        <div class="rounded-lg p-2 border" style="background:rgba(0,0,0,0.3);border-color:rgba(255,255,255,0.04)">
          <p class="text-[8px] text-slate-600 mono uppercase">P_net</p>
          <p id="dp_pnet" class="text-xs font-black mono text-slate-200">—</p>
        </div>
        <div class="rounded-lg p-2 border" style="background:rgba(0,0,0,0.3);border-color:rgba(255,255,255,0.04)">
          <p class="text-[8px] text-slate-600 mono uppercase">Em/pas</p>
          <p id="dp_emPerPass" class="text-xs font-black mono text-slate-200">—</p>
        </div>
        <div class="rounded-lg p-2 border" style="background:rgba(0,0,0,0.3);border-color:rgba(255,255,255,0.04)">
          <p class="text-[8px] text-slate-600 mono uppercase">P/V değirmen</p>
          <p id="dp_pvMill" class="text-xs font-black mono text-slate-200">—</p>
        </div>
      </div>
    </div>

    <!-- d50 grafiği -->
    <div class="glass-card p-4">
      <div class="flex items-center gap-2 mb-3" style="color:#60a5fa">
        <i class="fas fa-chart-line text-sm"></i>
        <h3 class="font-black uppercase text-xs tracking-widest">d₅₀ — Pas Sayısı İlişkisi</h3>
      </div>
      <canvas id="dp_chart" height="200" style="width:100%;background:transparent"></canvas>
    </div>

    <!-- SI grafiği -->
    <div class="glass-card p-4">
      <div class="flex items-center gap-2 mb-3" style="color:#a78bfa">
        <i class="fas fa-chart-scatter text-sm"></i>
        <h3 class="font-black uppercase text-xs tracking-widest">Stres Yoğunluğu Analizi</h3>
      </div>
      <canvas id="dp_siChart" height="160" style="width:100%;background:transparent"></canvas>
    </div>
  </div>

  <!-- Sağ: SI Analiz + Öneri + Boncuk Rehberi -->
  <div class="lg:col-span-4 space-y-4">
    <div class="glass-card p-4">
      <div class="flex items-center gap-2 mb-3" style="color:#a78bfa">
        <i class="fas fa-bullseye text-sm"></i>
        <h2 class="font-black uppercase text-xs tracking-widest">SI Optimum Analizi</h2>
      </div>
      <div id="dp_siAnalysis">
        <div class="text-center py-6 text-slate-600">
          <i class="fas fa-calculator text-2xl mb-2 block"></i>
          <p class="text-sm">Hesapla butonuna basın</p>
        </div>
      </div>
    </div>

    <div class="glass-card p-4">
      <div class="flex items-center gap-2 mb-3 text-green-400">
        <i class="fas fa-lightbulb text-sm"></i>
        <h2 class="font-black uppercase text-xs tracking-widest">Mühendis Önerisi</h2>
      </div>
      <div id="dp_recomm" class="text-[10px] text-slate-300 leading-relaxed space-y-2">
        <p class="text-slate-500 italic">Hesaplama sonrası öneriler burada görünecek.</p>
      </div>
    </div>

    <div class="glass-card p-4">
      <div class="flex items-center gap-2 mb-3" style="color:#60a5fa">
        <i class="fas fa-circle-info text-xs"></i>
        <h3 class="font-black uppercase text-xs tracking-widest">Boncuk Boyutu Rehberi</h3>
      </div>
      <div id="dp_beadGuide" class="space-y-1"></div>
    </div>
  </div>

</div>
```

- [ ] **Adım 2: Dinamik η tablosunu JS'e ekle**

`DP_MILL_ETA` sabitinin altına ekle:

```javascript
// Dinamik Bond verimlilik faktörü — pigment tipi + konsantrasyona göre
// Kaynak: Kwade (1999), Becker (2002) deneysel uyumu
const DP_ETA_BASE = {
    tio2:    0.42,
    fe2o3:   0.40,
    caco3:   0.45,
    organic: 0.35,
    cb:      0.30,
    baso4:   0.40,
};
// Konsantrasyon düzeltmesi: optimum %30-40; dışında düşer
function dpDynamicEta(pigType, solidPct) {
    const base = DP_ETA_BASE[pigType] || 0.40;
    // solidPct: 0–1 arası
    const pct = solidPct * 100;
    let corr = 1.0;
    if      (pct < 20) corr = 0.80;
    else if (pct < 25) corr = 0.90;
    else if (pct <= 45) corr = 1.00;
    else if (pct <= 55) corr = 0.90;
    else                corr = 0.75;
    return base * corr;
}
```

- [ ] **Adım 3: `dpCompute` içindeki sabit `etaBond = 0.40` satırını dinamik versiyonla değiştir**

Eski kod (satır ~3360):
```javascript
const etaBond = 0.40; // bead mill Bond verimlilik faktörü (Becker 2002)
```

Yeni kod:
```javascript
const etaBond = dpDynamicEta(p.pigType, p.solidPct);
```

- [ ] **Adım 4: `dpCompute` return objesine d80/d98/SPAN ekle**

`dpCompute` içindeki `return { ... }` bloğuna şunları ekle:

```javascript
// d80, d98, SPAN (log-normal yaklaşım)
const d50_t = p.d50target;
const d80_t  = d50_t * 1.45;
const d98_t  = d50_t * 2.30;
const d10_t  = d50_t * 0.55;
const d90_t  = d50_t * 1.80;
const SPAN   = (d90_t - d10_t) / d50_t;
```

Ve return'e: `d80_t, d98_t, SPAN, etaBond`

- [ ] **Adım 5: `dpRunCalc` içine d80/d98/SPAN + dinamik η DOM güncellemesini ekle**

`dp_emVal` güncelleme satırının ardına:

```javascript
document.getElementById('dp_etaDyn').textContent = 'η = ' + r.etaBond.toFixed(2) + ' (dinamik)';
document.getElementById('dp_d50out').textContent = p.d50target.toFixed(2) + ' µm';
document.getElementById('dp_d80out').textContent = r.d80_t.toFixed(2) + ' µm';
document.getElementById('dp_d98out').textContent = r.d98_t.toFixed(2) + ' µm';
document.getElementById('dp_span').textContent   = r.SPAN.toFixed(2);
```

Bead Mill badge'ini güncelle — `dpRunCalc` sonuna ekle:

```javascript
const mod2Badge = document.getElementById('dp_mod2_badge');
if (mod2Badge) {
    mod2Badge.textContent = '✓ ' + r.n_passes + ' pas';
    mod2Badge.style.cssText = 'background:rgba(74,222,128,0.15);color:#4ade80;border:1px solid rgba(74,222,128,0.3);padding:2px 8px;border-radius:4px;font-size:9px';
}
// Maliyet hesabı için state kaydet
window._millResult = { Em: r.Em, t_min: r.t_min, motorKw: parseFloat(document.getElementById('dp_motorKw').value) };
dpCostCalc(); // Maliyet otomatik güncelle
```

- [ ] **Adım 6: Test**

TiO₂, feed d₅₀=5 µm, hedef=0.3 µm, konsantrasyon %35 → hesapla.  
Beklenen: η ≈ 0.42 (sabit 0.40 yerine), d₈₀/d₉₈/SPAN gösterir, badge güncellenir.

- [ ] **Adım 7: Commit**

```bash
git add index.html
git commit -m "feat: bead mill enhanced with dynamic eta, d80/d98/SPAN distribution metrics"
```

---

## Task 4: Modül 3 — Letdown Risk Analizi

**Files:**
- Modify: `index.html` — `dp_mod3_body` içi + JS

- [ ] **Adım 1: `dp_mod3_body` içine Letdown HTML ekle**

`<!-- Letdown içeriği Task 4'te eklenir -->` yerine:

```html
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Parametreler -->
  <div class="space-y-3">
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Parametreler</div>
    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Reçine Tipi</label>
      <select id="ld_resin" class="input-dark">
        <option value="acrylic_water">Akrilik — Su Bazlı</option>
        <option value="acrylic_solvent">Akrilik — Solvent Bazlı</option>
        <option value="alkyd">Alkid (Solvent Bazlı)</option>
        <option value="epoxy">Epoksi</option>
        <option value="pu">Poliüretan</option>
        <option value="nc">Nitroselüloz</option>
      </select>
    </div>
    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Letdown Solvent</label>
      <select id="ld_solvent" class="input-dark">
        <option value="water">Su / Deiyonize Su</option>
        <option value="mineral">Mineral Spirit</option>
        <option value="toluene">Toluen / Ksilen</option>
        <option value="acetone">Aseton / MEK</option>
        <option value="ethanol">Etanol / İzopropanol</option>
        <option value="butanol">Bütanol / Glikol Eter</option>
      </select>
    </div>
    <div class="grid grid-cols-2 gap-2">
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Pasta Sıcaklığı (°C)</label>
        <input type="number" id="ld_t1" value="25" step="1" min="5" max="80" class="input-dark">
      </div>
      <div>
        <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Letdown Sıcaklığı (°C)</label>
        <input type="number" id="ld_t2" value="25" step="1" min="5" max="80" class="input-dark">
      </div>
    </div>
    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Ekleme Hızı</label>
      <select id="ld_addRate" class="input-dark">
        <option value="slow">Yavaş — damla damla</option>
        <option value="medium">Orta — kontrollü dökme</option>
        <option value="fast">Hızlı — tek seferde</option>
      </select>
    </div>
    <button onclick="ldCalc()" class="w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-widest text-white flex items-center justify-center gap-2 transition"
            style="background:linear-gradient(135deg,#0d9488,#14b8a6)">
      <i class="fas fa-shield-alt"></i> Risk Analiz Et
    </button>
  </div>

  <!-- Risk Sonucu -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Risk Değerlendirmesi</div>
    <div id="ld_result" class="rounded-xl p-5 text-center" style="background:#0d1628;border:1px solid rgba(255,255,255,0.06)">
      <i class="fas fa-shield-alt text-3xl text-slate-600 mb-3 block"></i>
      <p class="text-slate-500 text-sm">Analiz için parametreleri girin</p>
    </div>
  </div>

  <!-- Açıklama + Öneriler -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Mekanizma & Öneri</div>
    <div id="ld_detail" class="space-y-2 text-[10px] text-slate-300 leading-relaxed">
      <p class="text-slate-500 italic">Risk analizi sonuçları burada görünecek.</p>
    </div>
    <div class="mt-4 p-3 rounded-xl text-[9px] text-slate-400 leading-relaxed"
         style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.04)">
      <strong class="text-slate-300">Fizik notu:</strong> Letdown solventi reçineyle polarite uyumsuzluğu
      → dispersant pigment yüzeyinden soyulur → floating → renk hatası.
      <br><em class="text-slate-500">Kaynak: Paint.org Pigment Dispersion Wiki</em>
    </div>
  </div>

</div>
```

- [ ] **Adım 2: Letdown JS ekle**

`hsdPushToMod2` fonksiyonunun altına:

```javascript
// Uyumluluk matrisi: reçine + solvent → risk skoru (0=düşük, 1=orta, 2=yüksek)
const LD_COMPAT = {
    acrylic_water:   { water:0, mineral:2, toluene:2, acetone:1, ethanol:0, butanol:0 },
    acrylic_solvent: { water:2, mineral:1, toluene:0, acetone:0, ethanol:1, butanol:0 },
    alkyd:           { water:2, mineral:0, toluene:0, acetone:1, ethanol:1, butanol:1 },
    epoxy:           { water:1, mineral:1, toluene:0, acetone:0, ethanol:1, butanol:0 },
    pu:              { water:1, mineral:1, toluene:0, acetone:0, ethanol:1, butanol:0 },
    nc:              { water:2, mineral:1, toluene:0, acetone:0, ethanol:0, butanol:1 },
};

const LD_MECH = {
    0: 'Solvent uyumlu — dispersant kararlı kalır. Re-flokülasyon riski düşük.',
    1: 'Kısmi polarite farkı — dikkatli ekleme gerekli. Yavaş dökme + karıştırma öneriyle azaltılabilir.',
    2: 'Yüksek polarite uyumsuzluğu — dispersant yüzeyden soyulma riski. Pigment floating muhtemel.',
};

const LD_TIPS = {
    0: [
        '✓ Normal hızda letdown yapılabilir.',
        '✓ Sıcaklık farkına dikkat — ΔT < 10°C tutun.',
        '✓ Karıştırma süresince düşük-orta hız (200–400 RPM) yeterli.',
    ],
    1: [
        '⚠ Yavaş ekleme: pastayı letdown ortamına damla damla katın.',
        '⚠ Sıcaklıkları eşitleyin (ΔT < 5°C).',
        '⚠ Ekleme sonrası en az 15 dk karıştırın.',
        '⚠ Dispersant miktarını %10–15 artırmayı deneyin.',
    ],
    2: [
        '✗ Bu kombinasyon için farklı dispersant anchor grubu seçin.',
        '✗ Mümkünse letdown solventini değiştirin.',
        '✗ Kademeli seyreltme: önce %10 letdown, viskozite kontrol, sonra devam.',
        '✗ Re-flokülasyon göstergesi: Hegman düşüşü veya parlaklık kaybı.',
    ],
};

function ldCalc() {
    const resin   = document.getElementById('ld_resin').value;
    const solvent = document.getElementById('ld_solvent').value;
    const t1      = parseFloat(document.getElementById('ld_t1').value);
    const t2      = parseFloat(document.getElementById('ld_t2').value);
    const addRate = document.getElementById('ld_addRate').value;
    const pigType = document.getElementById('dp_pigType').value;

    let riskScore = LD_COMPAT[resin]?.[solvent] ?? 1;

    // ΔT düzeltmesi
    const dT = Math.abs(t2 - t1);
    if (dT > 20) riskScore = Math.min(2, riskScore + 1);
    else if (dT > 10) riskScore = Math.min(2, riskScore + 0.5);

    // Hızlı ekleme düzeltmesi
    if (addRate === 'fast') riskScore = Math.min(2, riskScore + 1);
    else if (addRate === 'medium' && riskScore > 0) riskScore = Math.min(2, riskScore + 0.3);

    // Karbon siyahı özel durum — her zaman dikkat
    if (pigType === 'cb' && riskScore < 1) riskScore = 1;

    const level = riskScore >= 1.5 ? 2 : riskScore >= 0.7 ? 1 : 0;
    const colors = ['#22c55e', '#f59e0b', '#ef4444'];
    const labels = ['DÜŞÜK RİSK', 'ORTA RİSK', 'YÜKSEK RİSK'];
    const icons  = ['fa-shield-check', 'fa-triangle-exclamation', 'fa-circle-xmark'];
    const bgs    = ['rgba(34,197,94,0.08)', 'rgba(245,158,11,0.08)', 'rgba(239,68,68,0.08)'];
    const borders= ['rgba(34,197,94,0.3)', 'rgba(245,158,11,0.3)', 'rgba(239,68,68,0.3)'];

    document.getElementById('ld_result').style.background  = bgs[level];
    document.getElementById('ld_result').style.border      = '1px solid ' + borders[level];
    document.getElementById('ld_result').innerHTML = `
        <i class="fas ${icons[level]} text-4xl mb-3 block" style="color:${colors[level]}"></i>
        <p class="text-xl font-black" style="color:${colors[level]}">${labels[level]}</p>
        <p class="text-[10px] text-slate-300 mt-2 leading-relaxed">${LD_MECH[level]}</p>
        ${dT > 10 ? `<p class="text-[9px] mt-2" style="color:#f59e0b">⚠ ΔT = ${dT.toFixed(0)}°C — sıcaklık farkı riski artırıyor</p>` : ''}
    `;

    const tips = LD_TIPS[level];
    document.getElementById('ld_detail').innerHTML = tips.map(t =>
        `<div class="p-2 rounded-lg" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.05)">${t}</div>`
    ).join('');

    // Badge
    const badge = document.getElementById('dp_mod3_badge');
    const badgeLabels = ['✓ Güvenli', '⚠ Dikkat', '✗ Risk'];
    const badgeColors = [
        'background:rgba(74,222,128,0.15);color:#4ade80;border:1px solid rgba(74,222,128,0.3)',
        'background:rgba(251,191,36,0.15);color:#fbbf24;border:1px solid rgba(251,191,36,0.3)',
        'background:rgba(248,113,113,0.15);color:#f87171;border:1px solid rgba(248,113,113,0.3)',
    ];
    badge.textContent = badgeLabels[level];
    badge.style.cssText = badgeColors[level] + ';padding:2px 8px;border-radius:4px;font-size:9px';
}
```

- [ ] **Adım 3: Test**

Dispersiyon → Modül 3 aç → Akrilik Su Bazlı + Mineral Spirit seç → "Risk Analiz Et".  
Beklenen: YÜKSEK RİSK (kırmızı), LD_COMPAT[acrylic_water][mineral] = 2.  
Su bazlı + Su seç → DÜŞÜK RİSK (yeşil).

- [ ] **Adım 4: Commit**

```bash
git add index.html
git commit -m "feat: letdown risk analysis module with compatibility matrix and recommendations"
```

---

## Task 5: Modül 4 — Maliyet & Enerji Analizi

**Files:**
- Modify: `index.html` — `dp_mod4_body` içi + JS

- [ ] **Adım 1: `dp_mod4_body` içine Maliyet HTML ekle**

`<!-- Maliyet içeriği Task 5'te eklenir -->` yerine:

```html
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Parametreler -->
  <div class="space-y-3">
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Enerji Parametreleri</div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Elektrik Birim Fiyatı (₺/kWh)</label>
      <input type="number" id="cost_elecPrice" value="4.50" step="0.10" min="0.01" class="input-dark"
             oninput="dpCostCalc()">
      <p class="text-[9px] text-slate-500 mt-1">Güncel tarife değişince buradan güncelleyin</p>
    </div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">HSD Motor Gücü (kW)</label>
      <input type="number" id="cost_hsdKw" value="7.5" step="0.5" min="0.1" class="input-dark"
             oninput="dpCostCalc()">
      <p class="text-[9px] text-slate-500 mt-1">Bilinmiyorsa tahmin kullanılır</p>
    </div>

    <div>
      <label class="text-[9px] font-black text-slate-500 uppercase block mb-1">Türkiye Grid CO₂ Faktörü (kg/kWh)</label>
      <input type="number" id="cost_co2factor" value="0.415" step="0.01" min="0.1" class="input-dark"
             oninput="dpCostCalc()">
      <p class="text-[9px] text-slate-500 mt-1">TEİAŞ 2023 ortalaması: 0.415 kg CO₂/kWh</p>
    </div>

    <button onclick="dpCostCalc()" class="w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-widest text-white flex items-center justify-center gap-2 transition"
            style="background:linear-gradient(135deg,#16a34a,#22c55e)">
      <i class="fas fa-coins"></i> Maliyet Hesapla
    </button>
  </div>

  <!-- Sonuçlar -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Maliyet Özeti</div>
    <div class="space-y-3">
      <div class="rounded-xl p-4 text-center" style="background:#0d1628;border:1px solid rgba(34,197,94,0.2)">
        <p class="text-[9px] text-green-400 uppercase font-black mb-1">Toplam Enerji</p>
        <p id="cost_energy" class="text-2xl font-black mono text-green-400">—</p>
        <p class="text-[9px] text-slate-500 mt-1">kWh/ton ürün</p>
      </div>
      <div class="rounded-xl p-4 text-center" style="background:#0d1628;border:1px solid rgba(251,191,36,0.2)">
        <p class="text-[9px] text-yellow-400 uppercase font-black mb-1">Enerji Maliyeti</p>
        <p id="cost_tl" class="text-2xl font-black mono text-yellow-400">—</p>
        <p class="text-[9px] text-slate-500 mt-1">₺/ton ürün</p>
      </div>
      <div class="rounded-xl p-4 text-center" style="background:#0d1628;border:1px solid rgba(148,163,184,0.1)">
        <p class="text-[9px] text-slate-400 uppercase font-black mb-1">CO₂ Tahmini</p>
        <p id="cost_co2" class="text-2xl font-black mono text-slate-300">—</p>
        <p class="text-[9px] text-slate-500 mt-1">kg CO₂/ton ürün</p>
      </div>
    </div>
  </div>

  <!-- Proses Süresi Özeti -->
  <div>
    <div class="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">Proses Süresi Özeti</div>
    <div class="space-y-2" id="cost_timeBreakdown">
      <div class="p-3 rounded-xl" style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.04)">
        <p class="text-[10px] text-slate-400">Bead mill ve HSD hesaplanınca otomatik dolar.</p>
      </div>
    </div>
    <div class="mt-4 p-3 rounded-xl text-[9px] text-slate-400 leading-relaxed"
         style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.04)">
      <strong class="text-slate-300">Not:</strong> Enerji verimini artırmak için SI optimum aralığında çalışın.
      Optimum SI → daha az pas → daha az enerji → daha az maliyet.
    </div>
  </div>

</div>
```

- [ ] **Adım 2: Maliyet JS fonksiyonunu ekle**

`ldCalc` fonksiyonunun altına:

```javascript
function dpCostCalc() {
    const elecPrice = parseFloat(document.getElementById('cost_elecPrice')?.value) || 4.50;
    const hsdKw     = parseFloat(document.getElementById('cost_hsdKw')?.value) || 7.5;
    const co2factor = parseFloat(document.getElementById('cost_co2factor')?.value) || 0.415;
    const batchKg   = parseFloat(document.getElementById('dp_batchKg')?.value) || 100;

    const millResult = window._millResult;
    const hsdResult  = window._hsdResult;

    if (!millResult && !hsdResult) return;

    const t_mill_h = millResult ? millResult.t_min / 60 : 0;
    const t_hsd_h  = hsdResult  ? hsdResult.t_pre / 60 : 0;
    const kw_mill  = millResult ? millResult.motorKw : 0;
    const kw_hsd   = hsdKw;

    const E_mill_kwh = kw_mill * t_mill_h;            // kWh (toplam batch)
    const E_hsd_kwh  = kw_hsd  * t_hsd_h;             // kWh (toplam batch)
    const E_total    = E_mill_kwh + E_hsd_kwh;         // kWh
    const E_per_ton  = E_total / (batchKg / 1000);     // kWh/ton

    const cost_tl    = E_per_ton * elecPrice;
    const co2_kg     = E_per_ton * co2factor;

    const fmt = (n, d=1) => isFinite(n) ? n.toFixed(d) : '—';

    document.getElementById('cost_energy').textContent = fmt(E_per_ton) + ' kWh/t';
    document.getElementById('cost_tl').textContent     = '₺' + fmt(cost_tl, 0);
    document.getElementById('cost_co2').textContent    = fmt(co2_kg, 1) + ' kg';

    // Süre özeti
    const lines = [];
    if (hsdResult)  lines.push(`<div class="flex justify-between p-2 rounded" style="background:rgba(124,58,237,0.08);border:1px solid rgba(124,58,237,0.2)"><span style="color:#c4b5fd">HSD Pre-mixer</span><span class="mono text-slate-200">${hsdResult.t_pre.toFixed(0)} dk</span></div>`);
    if (millResult) lines.push(`<div class="flex justify-between p-2 rounded" style="background:rgba(234,88,12,0.08);border:1px solid rgba(234,88,12,0.2)"><span style="color:#fdba74">Bead Mill</span><span class="mono text-slate-200">${millResult.t_min.toFixed(0)} dk</span></div>`);
    const totalMin = (hsdResult ? hsdResult.t_pre : 0) + (millResult ? millResult.t_min : 0);
    if (lines.length > 0) {
        lines.push(`<div class="flex justify-between p-2 rounded mt-1" style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.2)"><strong style="color:#86efac">Toplam</strong><strong class="mono text-green-400">${totalMin.toFixed(0)} dk</strong></div>`);
    }
    if (lines.length > 0) document.getElementById('cost_timeBreakdown').innerHTML = lines.join('');

    // Badge
    const badge = document.getElementById('dp_mod4_badge');
    if (badge && isFinite(cost_tl)) {
        badge.textContent = '₺' + fmt(cost_tl, 0) + '/ton';
        badge.style.cssText = 'background:rgba(74,222,128,0.15);color:#86efac;border:1px solid rgba(34,197,94,0.3);padding:2px 8px;border-radius:4px;font-size:9px';
    }
}
```

- [ ] **Adım 3: Test**

1. Modül 1 → HSD hesapla → Modül 2'ye aktar  
2. Modül 2 → Bead Mill hesapla  
3. Modül 4 → Maliyet Hesapla tıkla → kWh/t, ₺/t, CO₂ görünür  
4. Elektrik fiyatını 4.50'den 6.00'ya çek → ₺/t anında güncellenir  
5. Badge "₺XXX/ton" formatında güncellenir

- [ ] **Adım 4: Commit**

```bash
git add index.html
git commit -m "feat: cost & energy module with dynamic electricity price, CO2 estimate, process time summary"
```

---

## Task 6: Son Düzeltmeler ve Temizlik

**Files:**
- Modify: `index.html`

- [ ] **Adım 1: Modüllerin varsayılan açık/kapalı durumunu ayarla**

Sayfa yüklendiğinde Modül 1 açık, diğerleri kapalı olsun. Mevcut `dp_calcBtn.onclick` bağlamasının hemen altına ekle:

```javascript
// Accordion başlangıç durumu: Mod1 açık, 2-3-4 kapalı
['dp_mod2_body','dp_mod3_body','dp_mod4_body'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
});
['dp_mod2_arrow','dp_mod3_arrow','dp_mod4_arrow'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.transform = '';
});
```

- [ ] **Adım 2: `dp_resetBtn` onclick'ini güncelle**

Eski reset handler'ı (satır ~3656) yeni ID'lere göre güncelle:

```javascript
document.getElementById('dp_resetBtn').onclick = () => {
    ['dp_siVal','dp_emVal','dp_timeVal','dp_passVal','dp_pnet','dp_pvMill','dp_emPerPass',
     'dp_d50out','dp_d80out','dp_d98out','dp_span','dp_etaDyn'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = '—';
    });
    const ctx1 = document.getElementById('dp_chart')?.getContext('2d');
    if (ctx1) ctx1.clearRect(0,0,9999,9999);
    const ctx2 = document.getElementById('dp_siChart')?.getContext('2d');
    if (ctx2) ctx2.clearRect(0,0,9999,9999);
    document.getElementById('dp_siAnalysis').innerHTML =
        '<div class="text-center py-6 text-slate-600"><p>Hesapla butonuna basın</p></div>';
    window._millResult = null;
    window._hsdResult  = null;
};
```

- [ ] **Adım 3: Eski yedek HTML bloğunu (Task 1 Adım 1'de işaretlenenler) sil**

Sayfa artık yeni yapıda çalışıyorsa eski `<!-- YEDEK BAŞLANGICI -->...<!-- YEDEK SONU -->` bloklarını temizle.

- [ ] **Adım 4: Kapsamlı test**

Aşağıdaki senaryoyu baştan sona dene:

1. Pigment = TiO₂, hedef = 0.3 µm, batch = 100 kg, konsantrasyon = %35, baz = su bazlı
2. Modül 1: D=250, T=750, N=1450 → HSD Hesapla → TS≈19 m/s (yeşil), oran=0.33 → Modül 2'ye Aktar
3. Modül 2 açılır, feed d₅₀=4.0 otomatik dolu → Bead Mill Hesapla → pas, süre, d80/d98/SPAN görünür
4. Modül 3: Akrilik Su Bazlı + Mineral Spirit → Risk Analiz Et → Yüksek Risk (kırmızı)
5. Modül 4: fiyat=4.50 → Maliyet Hesapla → kWh/t, ₺/t, CO₂ görünür → fiyatı 6.00 yap → otomatik güncellenir
6. Tüm badge'ler accordion başlıklarında gösterilir

- [ ] **Adım 5: Final commit**

```bash
git add index.html
git commit -m "feat: dispersion page complete - 4-module accordion, HSD+BeadMill+Letdown+Cost"
```
