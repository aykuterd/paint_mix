# Torispherical Alt Bombe — CFD Tab Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Silindirik tankların torispherical (Klöpperboden, DIN 28011) alt bombesini CFD tabında hesaplara ve çizime dahil etmek.

**Architecture:** Yaklaşım A — V_bombe = 0.0847·T³ sıvı yüksekliği hesabından çıkarılır, bilgi panelinde gösterilir, canvas'ta bezier eğrisi ile çizilir. `cfd-engine.js` fizik modeli dokunulmaz.

**Tech Stack:** Vanilla JS, Canvas 2D API, HTML

---

## Dosya Haritası

| Dosya | Değişiklik |
|-------|-----------|
| `cfd-ui.js:5-35` | `cfdGetParams()` — V_bombe, h_bombe, Vtotal ekle, H_liq formülü güncelle |
| `cfd-ui.js:37-57` | `cfdUpdateLiqInfo()` — bombe vol + derinlik satırları + doluluk% düzelt |
| `cfd-ui.js:549-552` | `cfdApplyTankSelection()` — kg_def'e V_bombe ekle |
| `cfd-render.js:195-211` | `cfdDrawSideView()` — strokeRect → duvarlar + bezier bombe |
| `cfd-page.html:66-69` | Dolum bilgi paneli — 2 yeni span satırı |

---

## Task 1: cfdGetParams() — Bombe Hacim Hesabı

**Files:**
- Modify: `cfd-ui.js:5-35`

- [ ] **Step 1: cfd-ui.js satır 11-16'yı değiştir**

Mevcut (satır 11-16):
```js
  // Sıvı hacmi (m³) = kg / yoğunluk; sıvı yüksekliği = V / (π·T²/4)
  const A_section = Math.PI / 4 * T * T;             // m²
  const V_liq     = (kg > 0 && rho > 0) ? kg / rho : 0; // m³
  let   H_liq     = A_section > 1e-9 ? V_liq / A_section : 0;
  // Sıvı taşmasın, minimum altı sıfır olmasın
  H_liq = Math.max(0.05, Math.min(H_liq, Htank));
```

Yeni:
```js
  // Torispherical bombe (DIN 28011 Klöpperboden): V = 0.0847·T³, h = T·(1−√0.65)
  const V_bombe   = 0.0847 * T * T * T;
  const h_bombe   = T * (1 - Math.sqrt(0.65));
  const A_section = Math.PI / 4 * T * T;             // m²
  const Vtotal    = A_section * Htank + V_bombe;      // toplam tank kapasitesi m³
  const V_liq     = (kg > 0 && rho > 0) ? kg / rho : 0; // m³
  // Sıvı önce bombeyi, sonra silindiri doldurur
  const V_cyl     = Math.max(0, V_liq - V_bombe);
  let   H_liq     = A_section > 1e-9 ? V_cyl / A_section : 0;
  // Sıvı taşmasın
  H_liq = Math.max(0, Math.min(H_liq, Htank));
```

- [ ] **Step 2: cfdGetParams() return objesine yeni alanlar ekle**

`return { ... }` bloğunda mevcut `Vliq: V_liq,` satırının yanına ekle:
```js
    Vliq:   V_liq,
    Vtotal,
    V_bombe,
    h_bombe,
```

- [ ] **Step 3: Minimum H_liq guard'ı düzelt**

Satır 16'daki `Math.max(0.05, ...)` → `Math.max(0, ...)` olarak değiştirildi (yukarıdaki kod bloğunda zaten). Taşma olmadığını doğrula.

- [ ] **Step 4: Browser'da doğrula**

`index.html` aç → CFD sekmesi → Console'da `cfdGetParams()` çağır:
```js
p = cfdGetParams()
console.log(p.V_bombe, p.h_bombe, p.Vtotal, p.H)
```
T=1.3 için beklenen: V_bombe≈0.186, h_bombe≈0.252, H değişmiş (küçülmüş)

- [ ] **Step 5: Commit**
```bash
git add cfd-ui.js
git commit -m "feat: add torispherical bombe volume to cfdGetParams (DIN 28011)"
```

---

## Task 2: cfd-page.html — Bombe Bilgi Satırları

**Files:**
- Modify: `cfd-page.html:66-69`

- [ ] **Step 1: Dolum bilgi paneline 2 satır ekle**

`cfd-page.html` satır 67-68 arasına (sıvı yüksekliği ile üstten boşluk arasına) ekle:
```html
                  <div class="flex justify-between"><span class="text-slate-500">Bombe (DIN 28011):</span><span id="cfd_bombeVol" class="text-violet-400">--</span></div>
                  <div class="flex justify-between"><span class="text-slate-500">Bombe derinliği:</span><span id="cfd_bombeH" class="text-violet-400">--</span></div>
```

Tam konum — mevcut blok şöyle görünmeli:
```html
<div class="flex justify-between"><span class="text-slate-500">Sıvı hacmi:</span><span id="cfd_liqVol" class="text-cyan-300">--</span></div>
<div class="flex justify-between"><span class="text-slate-500">Sıvı yüksekliği H_l:</span><span id="cfd_liqH" class="text-cyan-300">--</span></div>
<div class="flex justify-between"><span class="text-slate-500">Bombe (DIN 28011):</span><span id="cfd_bombeVol" class="text-violet-400">--</span></div>
<div class="flex justify-between"><span class="text-slate-500">Bombe derinliği:</span><span id="cfd_bombeH" class="text-violet-400">--</span></div>
<div class="flex justify-between"><span class="text-slate-500">Üstten boşluk:</span><span id="cfd_liqGap" class="text-cyan-300">--</span></div>
<div class="flex justify-between"><span class="text-slate-500">Doluluk:</span><span id="cfd_liqFill" class="text-cyan-300">--</span></div>
```

- [ ] **Step 2: Commit**
```bash
git add cfd-page.html
git commit -m "feat: add bombe vol/depth display spans to CFD info panel"
```

---

## Task 3: cfdUpdateLiqInfo() — Panel Güncelleme

**Files:**
- Modify: `cfd-ui.js:37-57`

- [ ] **Step 1: cfdUpdateLiqInfo'ya bombe alanlarını ekle**

Mevcut fonksiyon (satır 37-57):
```js
function cfdUpdateLiqInfo(p) {
  const volEl  = document.getElementById('cfd_liqVol');
  const hEl    = document.getElementById('cfd_liqH');
  const gapEl  = document.getElementById('cfd_liqGap');
  const fillEl = document.getElementById('cfd_liqFill');
  if (!volEl) return;
  const gap = Math.max(0, p.Htank - p.H);
  const fillPct = p.Htank > 0 ? (p.H / p.Htank) * 100 : 0;
  volEl.innerText  = (p.Vliq * 1000).toFixed(0) + ' L  (' + p.Vliq.toFixed(3) + ' m³)';
  hEl.innerText    = p.H.toFixed(2) + ' m';
  gapEl.innerText  = gap.toFixed(2) + ' m';
  fillEl.innerText = fillPct.toFixed(0) + '%';
```

Tüm fonksiyon başını şununla değiştir:
```js
function cfdUpdateLiqInfo(p) {
  const volEl    = document.getElementById('cfd_liqVol');
  const hEl      = document.getElementById('cfd_liqH');
  const gapEl    = document.getElementById('cfd_liqGap');
  const fillEl   = document.getElementById('cfd_liqFill');
  const bombeVolEl = document.getElementById('cfd_bombeVol');
  const bombeHEl   = document.getElementById('cfd_bombeH');
  if (!volEl) return;
  const gap = Math.max(0, p.Htank - p.H);
  // Doluluk % toplam tank kapasitesine (silindir + bombe) göre
  const fillPct = p.Vtotal > 0 ? (p.Vliq / p.Vtotal) * 100 : 0;
  volEl.innerText  = (p.Vliq * 1000).toFixed(0) + ' L  (' + p.Vliq.toFixed(3) + ' m³)';
  hEl.innerText    = p.H.toFixed(2) + ' m';
  if (bombeVolEl) bombeVolEl.innerText = (p.V_bombe * 1000).toFixed(0) + ' L  (' + p.V_bombe.toFixed(3) + ' m³)';
  if (bombeHEl)   bombeHEl.innerText   = p.h_bombe.toFixed(3) + ' m';
  gapEl.innerText  = gap.toFixed(2) + ' m';
  fillEl.innerText = Math.min(100, fillPct).toFixed(0) + '%';
```

- [ ] **Step 2: Browser'da doğrula**

CFD sekmesi açık — T ve kg/rho değerlerini değiştir → Bombe satırlarının güncellendiğini gör.
T=1.3, kg=2400, rho=1200 → V_bombe ≈ 186 L, h_bombe ≈ 0.252 m

- [ ] **Step 3: Commit**
```bash
git add cfd-ui.js
git commit -m "feat: show bombe volume/depth in CFD liquid info panel"
```

---

## Task 4: cfd-render.js — Curved Bottom Çizimi

**Files:**
- Modify: `cfd-render.js:195-211`

- [ ] **Step 1: Tank kontur çizimini değiştir**

Mevcut (satır 195-211):
```js
  // ── Tank sınırı ──────────────────────────────────────────────
  ctx.strokeStyle = 'rgba(100,116,139,0.8)'; ctx.lineWidth = 2;
  // Sol duvar, sağ duvar, taban, üst
  ctx.strokeRect(pad.left, pad.top, dW, dH);
  // Merkez eksen (kesik çizgi)
  ctx.strokeStyle = 'rgba(100,116,139,0.35)'; ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.beginPath(); ctx.moveTo(cx, pad.top); ctx.lineTo(cx, pad.top+dH); ctx.stroke();
  ctx.setLineDash([]);

  // Yuvarlatılmış taban
  ctx.beginPath();
  ctx.strokeStyle = 'rgba(100,116,139,0.4)'; ctx.lineWidth = 1.5;
  ctx.setLineDash([4,4]);
  ctx.moveTo(pad.left, pad.top+dH);
  ctx.quadraticCurveTo(pad.left+dW/2, pad.top+dH+15, pad.left+dW, pad.top+dH);
  ctx.stroke(); ctx.setLineDash([]);
```

Tamamını şununla değiştir:
```js
  // ── Tank sınırı — torispherical bombe ────────────────────────
  const botY = pad.top + dH;
  const bombePx = Math.min(Math.round(dH * (p.h_bombe || 0) / (p.Htank || 1)), pad.bottom - 4);

  ctx.strokeStyle = 'rgba(100,116,139,0.8)'; ctx.lineWidth = 2;
  // Üst kenar
  ctx.beginPath();
  ctx.moveTo(pad.left, pad.top);
  ctx.lineTo(pad.left + dW, pad.top);
  ctx.stroke();
  // Sol duvar
  ctx.beginPath();
  ctx.moveTo(pad.left, pad.top);
  ctx.lineTo(pad.left, botY);
  ctx.stroke();
  // Sağ duvar
  ctx.beginPath();
  ctx.moveTo(pad.left + dW, pad.top);
  ctx.lineTo(pad.left + dW, botY);
  ctx.stroke();

  // Torispherical bombe eğrisi (sol yarı: duvar→eksen, sağ yarı: ayna)
  ctx.strokeStyle = 'rgba(100,200,255,0.85)'; ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(pad.left, botY);
  ctx.bezierCurveTo(
    pad.left,          botY + bombePx * 0.55,
    cx - dW * 0.08,    botY + bombePx,
    cx,                botY + bombePx
  );
  ctx.bezierCurveTo(
    cx + dW * 0.08,    botY + bombePx,
    pad.left + dW,     botY + bombePx * 0.55,
    pad.left + dW,     botY
  );
  ctx.stroke();

  // Merkez eksen (kesik çizgi)
  ctx.strokeStyle = 'rgba(100,116,139,0.35)'; ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.beginPath(); ctx.moveTo(cx, pad.top); ctx.lineTo(cx, botY + bombePx); ctx.stroke();
  ctx.setLineDash([]);
```

- [ ] **Step 2: Bombe iç dolgusu ekle**

Step 1'de yazdığın yeni tank sınırı bloğunun EN BAŞINA (const botY tanımından önce) dolgu kodunu ekle, böylece bombe konturundan önce çizilir:

```js
  // ── Tank sınırı — torispherical bombe ────────────────────────
  const botY    = pad.top + dH;
  const bombePx = Math.min(Math.round(dH * (p.h_bombe || 0) / (p.Htank || 1)), pad.bottom - 4);

  // Bombe iç dolgusu — konturdan önce çizilir (arkada kalır)
  if (bombePx > 0 && p.Vliq > 0) {
    const bombeAlpha = Math.min(0.18, 0.08 + (p.Vliq / (p.V_bombe || 0.001)) * 0.10);
    ctx.fillStyle = `rgba(56,189,248,${bombeAlpha})`;
    ctx.beginPath();
    ctx.moveTo(pad.left, botY);
    ctx.bezierCurveTo(pad.left, botY+bombePx*0.55, cx-dW*0.08, botY+bombePx, cx, botY+bombePx);
    ctx.bezierCurveTo(cx+dW*0.08, botY+bombePx, pad.left+dW, botY+bombePx*0.55, pad.left+dW, botY);
    ctx.closePath();
    ctx.fill();
  }

  // ... (geri kalan Step 1 kodu: üst kenar, duvarlar, eğri kontur)
```

Yani Step 1'deki kod bloğu şu sırayla olmalı: `botY` → `bombePx` → fill → üst kenar → sol duvar → sağ duvar → bombe eğrisi → eksen.

- [ ] **Step 3: Browser'da doğrula**

index.html → CFD sekmesi → Canvas'ta bombe eğrisi görünmeli (mavi kontur, içi hafif dolgu). T değişince eğri orantılı büyümeli/küçülmeli.

- [ ] **Step 4: Commit**
```bash
git add cfd-render.js
git commit -m "feat: draw torispherical bombe bottom on CFD canvas (bezier curve)"
```

---

## Task 5: cfdApplyTankSelection() — kg_def Düzeltmesi

**Files:**
- Modify: `cfd-ui.js:549-552`

- [ ] **Step 1: kg_def hesabına V_bombe ekle**

Mevcut (satır 549-552):
```js
  // Varsayılan sipariş miktarı: tankın "kullanilabilir_lt" hacmini varsayılan
  // yoğunluk (1200) ile dolduran kg miktarı.
  const rho_def = 1200;
  const kg_def = Math.round((tank.kullanilabilir_lt || 1500) * rho_def / 1000);
```

Şununla değiştir:
```js
  // Varsayılan sipariş miktarı: silindir + bombe hacmini dolduran kg
  const rho_def = 1200;
  const V_bombe_tank = 0.0847 * T * T * T;
  const V_cyl_tank   = (tank.kullanilabilir_lt || 1500) / 1000; // m³
  const kg_def = Math.round((V_cyl_tank + V_bombe_tank) * rho_def);
```

- [ ] **Step 2: Browser'da doğrula**

Tank seçicisinden herhangi bir tank seç → kg alanı öncekinden biraz daha büyük çıkmalı (bombe hacmi kadar fark). T=1.3 için fark ≈ 0.186 m³ × 1200 kg/m³ ≈ 223 kg.

- [ ] **Step 3: Commit**
```bash
git add cfd-ui.js
git commit -m "feat: include bombe volume in tank selector default kg calculation"
```

---

## Task 6: Entegrasyon Testi

- [ ] **Step 1: CFD simülasyonu başlat ve doğrula**

index.html aç → CFD sekmesi:
1. T=1.3, Htank=2.27, kg=2400, rho=1200 gir
2. Bilgi panelinde Bombe: ~186 L, Derinlik: ~0.252 m görünmeli
3. Canvas'ta curved bottom görünmeli
4. Simülasyonu başlat → hücreler normal çalışmalı (bombe altında hücre yok)
5. kg=100 (çok az sıvı → sadece bombe) → H_liq=0, doluluk<%  düşük

- [ ] **Step 2: Edge case — sıvı sadece bombe içinde**

kg = round(0.186 × 1200) = 223 kg gir → H_liq = 0, doluluk ~= 186/V_total × 100

- [ ] **Step 3: T değiştir**

T=0.8 → V_bombe = 0.0847 × 0.512 ≈ 0.043 m³ (43 L), h_bombe ≈ 0.155 m → canvas eğrisi küçülmeli

- [ ] **Step 4: Final commit**
```bash
git add -A
git commit -m "chore: torispherical bombe integration complete"
```
